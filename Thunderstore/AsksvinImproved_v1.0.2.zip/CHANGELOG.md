| `Version` | `Update Notes`                                                        |
|-----------|-----------------------------------------------------------------------|
| 1.0.2     | - Fix manifest.json description to reflect removal of code from 1.0.1 |
| 1.0.1     | - Remove the Lava toleration code. It's now in the base game.         |
| 1.0.0     | - Initial Release                                                     |